package ed.example.sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity  implements SensorEventListener {

    private SoundPool spool;
    private int sound1;
    private AudioManager audioManager;
    private CheckBox check;
    private TextView ValorX,ValorY,ValorZ,LogText;
    private  float X,Y,Z;
    private ScrollView scrollView;
    private SensorManager Sensores;
    private Sensor SensorAce;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LogText =findViewById(R.id.textView2);
        ValorX =findViewById(R.id.textView4);
        ValorY =findViewById(R.id.textView6);
        ValorZ =findViewById(R.id.textView8);
        check =findViewById(R.id.checkBox);
        ValorX.setText("0");
        ValorY.setText("0");
        ValorZ.setText("0");
        X=0;
        Y=0;
        Z=0;



        scrollView =findViewById(R.id.scroll);
        Sensores= (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor>
                listSensores =Sensores.getSensorList(Sensor.TYPE_ALL);
        for(Sensor sensor:listSensores)
        {
            Log("sensores" + sensor.getName().toString());
        }

        SensorAce= Sensores.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensores.registerListener(this,SensorAce,SensorManager.SENSOR_DELAY_NORMAL);





        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
            AudioAttributes attributes =new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            spool =new SoundPool.Builder()
                    .setAudioAttributes(attributes)
                    .setMaxStreams(10).build();
        }
        else{
            spool =new SoundPool(6,audioManager.STREAM_MUSIC,0);
        }
        sound1=spool.load(this,R.raw.latigo,1);










    }













    public void suenaboton1(){
        spool.play(sound1,1,1,1,0,1);
    }


    private void Log(String S)    {
        LogText.append("\n"+ S);
        scrollView.post(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(scrollView.FOCUS_DOWN);
            }
        });
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
     Sensor mySensor =sensorEvent.sensor;



if(mySensor.getType() == Sensor.TYPE_ACCELEROMETER) {
    try {

        Float XA=sensorEvent.values[0];
        Float YA=sensorEvent.values[1];;
        Float ZA=sensorEvent.values[2];;

        if(Math.abs(XA-X)>=1  ||   Math.abs(YA-Y)>=1 || Math.abs(ZA-Z)>=1  ){
            ValorX.setText(String.valueOf(sensorEvent.values[0]));
            ValorY.setText(String.valueOf(sensorEvent.values[1]));
            ValorZ.setText(String.valueOf(sensorEvent.values[2]));
        }

        if(Math.abs(XA-X)>=5  ){
            if(check.isChecked()){
            suenaboton1();
            Log("encendido");
            }
            else{
                Log("apagado");
            }

        }


    } catch (Exception e) {
    }
}


    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }



    //crear check box latigo con sonido para que cuando se mueva suene


}









